import type { ConversationalResponse, Contact, ScheduleItem, Expense, DiaryEntry, ChatMessage } from "../types.ts";
import { processChat as processWithGemini } from "./geminiService.ts";
import { processWithLocalModel, convertToConversationalResponse, checkLocalModelHealth } from "./localModelService.ts";

/**
 * 하이브리드 모델 서비스
 *
 * 우선순위:
 * 1. 로컬 LoRA 모델 (학습된 모델 사용)
 * 2. Gemini API (OCR, 웹 검색, 복잡한 질문 등)
 *
 * 작동 방식:
 * - 로컬 모델이 처리 가능한 요청인지 먼저 판단
 * - 처리 가능하면 로컬 모델 사용
 * - 처리 불가능하거나 오류 발생시 Gemini로 폴백
 */

// 로컬 모델 서버 상태 캐시
let localModelAvailable: boolean | null = null;
let lastHealthCheck: number = 0;
const HEALTH_CHECK_INTERVAL = 30000; // 30초마다 상태 확인

/**
 * 로컬 모델 서버 사용 가능 여부 확인 (캐싱 포함)
 */
async function isLocalModelAvailable(): Promise<boolean> {
  const now = Date.now();

  // 최근에 확인했으면 캐시된 결과 반환
  if (localModelAvailable !== null && (now - lastHealthCheck) < HEALTH_CHECK_INTERVAL) {
    return localModelAvailable;
  }

  // 상태 확인
  localModelAvailable = await checkLocalModelHealth();
  lastHealthCheck = now;

  if (!localModelAvailable) {
    console.warn("⚠️ 로컬 모델 서버가 실행 중이지 않습니다. Gemini만 사용됩니다.");
    console.warn("   서버를 시작하려면: python server.py");
  }

  return localModelAvailable;
}

/**
 * 하이브리드 처리 함수
 *
 * @param chatHistory 대화 기록
 * @param text 사용자 입력 텍스트
 * @param image 첨부된 이미지 (있는 경우)
 * @param contextData 사용자의 기존 데이터
 * @returns 처리 결과
 */
export const processChat = async (
  chatHistory: ChatMessage[],
  text: string,
  image: File | null,
  contextData: {
    contacts: Partial<Contact>[];
    schedule: ScheduleItem[];
    expenses: Expense[];
    diary: DiaryEntry[];
  }
): Promise<ConversationalResponse> => {
  console.log("\n" + "█".repeat(60));
  console.log("🔀 [하이브리드 서비스] 요청 처리 시작");
  console.log("📝 [사용자 입력]:", text.substring(0, 100) + (text.length > 100 ? "..." : ""));
  console.log("🖼️  [이미지 첨부]:", image ? "있음" : "없음");
  console.log("█".repeat(60) + "\n");

  // 1. 이미지가 있으면 무조건 Gemini 사용 (OCR 필요)
  if (image) {
    console.log("🎯 [모델 선택] 이미지 처리 필요 → Gemini API 사용");
    console.log("📸 [이유] 이미지 분석 및 OCR은 Gemini만 가능\n");

    const result = await processWithGemini(chatHistory, text, image, contextData);

    console.log("✅ [Gemini 처리 완료]");
    console.log("💬 [답변]:", result.answer.substring(0, 100) + (result.answer.length > 100 ? "..." : ""));
    console.log("📋 [파싱 결과]:");
    console.log("   - 연락처:", result.dataExtraction.contacts.length, "개", result.dataExtraction.contacts);
    console.log("   - 일정:", result.dataExtraction.schedule.length, "개", result.dataExtraction.schedule);
    console.log("   - 가계부:", result.dataExtraction.expenses.length, "개", result.dataExtraction.expenses);
    console.log("   - 메모:", result.dataExtraction.diary.length, "개", result.dataExtraction.diary);
    if (result.dataModification) {
      console.log("🔧 [수정 요청]:");
      console.log("   - 연락처:", result.dataModification.contacts?.length || 0, "개", result.dataModification.contacts);
      console.log("   - 일정:", result.dataModification.schedule?.length || 0, "개", result.dataModification.schedule);
      console.log("   - 가계부:", result.dataModification.expenses?.length || 0, "개", result.dataModification.expenses);
      console.log("   - 메모:", result.dataModification.diary?.length || 0, "개", result.dataModification.diary);
    }
    if (result.dataDeletion) {
      console.log("🗑️  [삭제 요청]:");
      console.log("   - 연락처:", result.dataDeletion.contacts?.length || 0, "개", result.dataDeletion.contacts);
      console.log("   - 일정:", result.dataDeletion.schedule?.length || 0, "개", result.dataDeletion.schedule);
      console.log("   - 가계부:", result.dataDeletion.expenses?.length || 0, "개", result.dataDeletion.expenses);
      console.log("   - 메모:", result.dataDeletion.diary?.length || 0, "개", result.dataDeletion.diary);
    }
    console.log("█".repeat(60) + "\n");

    return result;
  }

  // 2. 로컬 모델 서버 상태 확인
  const localAvailable = await isLocalModelAvailable();

  if (!localAvailable) {
    console.log("🎯 [모델 선택] 로컬 서버 비활성화 → Gemini API 사용");
    console.log("⚠️  [이유] 로컬 모델 서버가 실행 중이지 않음\n");

    const result = await processWithGemini(chatHistory, text, image, contextData);

    console.log("✅ [Gemini 처리 완료]");
    console.log("💬 [답변]:", result.answer.substring(0, 100) + (result.answer.length > 100 ? "..." : ""));
    console.log("📋 [파싱 결과]:");
    console.log("   - 연락처:", result.dataExtraction.contacts.length, "개", result.dataExtraction.contacts);
    console.log("   - 일정:", result.dataExtraction.schedule.length, "개", result.dataExtraction.schedule);
    console.log("   - 가계부:", result.dataExtraction.expenses.length, "개", result.dataExtraction.expenses);
    console.log("   - 메모:", result.dataExtraction.diary.length, "개", result.dataExtraction.diary);
    if (result.dataModification) {
      console.log("🔧 [수정 요청]:");
      console.log("   - 연락처:", result.dataModification.contacts?.length || 0, "개", result.dataModification.contacts);
      console.log("   - 일정:", result.dataModification.schedule?.length || 0, "개", result.dataModification.schedule);
      console.log("   - 가계부:", result.dataModification.expenses?.length || 0, "개", result.dataModification.expenses);
      console.log("   - 메모:", result.dataModification.diary?.length || 0, "개", result.dataModification.diary);
    }
    if (result.dataDeletion) {
      console.log("🗑️  [삭제 요청]:");
      console.log("   - 연락처:", result.dataDeletion.contacts?.length || 0, "개", result.dataDeletion.contacts);
      console.log("   - 일정:", result.dataDeletion.schedule?.length || 0, "개", result.dataDeletion.schedule);
      console.log("   - 가계부:", result.dataDeletion.expenses?.length || 0, "개", result.dataDeletion.expenses);
      console.log("   - 메모:", result.dataDeletion.diary?.length || 0, "개", result.dataDeletion.diary);
    }
    console.log("█".repeat(60) + "\n");

    return result;
  }

  // 3. 로컬 모델 시도
  try {
    console.log("🎯 [모델 선택] 1차: 로컬 LoRA 모델 시도");
    console.log("🤖 [모델 정보] GPT-2 + LoRA Fine-tuned\n");

    const localResult = await processWithLocalModel(text, contextData);

    // 4. 로컬 모델이 처리 가능한지 확인
    if (localResult.canHandle) {
      console.log("✅ [로컬 모델 처리 성공]");
      console.log("🎯 [최종 모델]:", localResult.usedModel);
      console.log("💬 [답변]:", localResult.answer);
      console.log("📊 [처리 내역]:", localResult.processingDetails);
      console.log("📋 [파싱 결과]:");
      console.log("   - 연락처:", localResult.dataExtraction.contacts.length, "개", localResult.dataExtraction.contacts);
      console.log("   - 일정:", localResult.dataExtraction.schedule.length, "개", localResult.dataExtraction.schedule);
      console.log("   - 가계부:", localResult.dataExtraction.expenses.length, "개", localResult.dataExtraction.expenses);
      console.log("   - 메모:", localResult.dataExtraction.diary.length, "개", localResult.dataExtraction.diary);
      console.log("█".repeat(60) + "\n");

      return convertToConversationalResponse(localResult);
    }

    // 5. 로컬 모델이 처리 불가능 → Gemini로 폴백
    console.log("⚠️  [로컬 모델 처리 불가]");
    console.log("📋 [사유]:", localResult.processingDetails);
    console.log("🔄 [폴백] Gemini API로 전환\n");

    const geminiResult = await processWithGemini(chatHistory, text, image, contextData);

    console.log("✅ [Gemini 처리 완료]");
    console.log("🎯 [최종 모델]: Gemini API (폴백)");
    console.log("💬 [답변]:", geminiResult.answer.substring(0, 100) + (geminiResult.answer.length > 100 ? "..." : ""));
    console.log("📋 [파싱 결과]:");
    console.log("   - 연락처:", geminiResult.dataExtraction.contacts.length, "개", geminiResult.dataExtraction.contacts);
    console.log("   - 일정:", geminiResult.dataExtraction.schedule.length, "개", geminiResult.dataExtraction.schedule);
    console.log("   - 가계부:", geminiResult.dataExtraction.expenses.length, "개", geminiResult.dataExtraction.expenses);
    console.log("   - 메모:", geminiResult.dataExtraction.diary.length, "개", geminiResult.dataExtraction.diary);
    if (geminiResult.dataModification) {
      console.log("🔧 [수정 요청]:");
      console.log("   - 연락처:", geminiResult.dataModification.contacts?.length || 0, "개", geminiResult.dataModification.contacts);
      console.log("   - 일정:", geminiResult.dataModification.schedule?.length || 0, "개", geminiResult.dataModification.schedule);
      console.log("   - 가계부:", geminiResult.dataModification.expenses?.length || 0, "개", geminiResult.dataModification.expenses);
      console.log("   - 메모:", geminiResult.dataModification.diary?.length || 0, "개", geminiResult.dataModification.diary);
    }
    if (geminiResult.dataDeletion) {
      console.log("🗑️  [삭제 요청]:");
      console.log("   - 연락처:", geminiResult.dataDeletion.contacts?.length || 0, "개", geminiResult.dataDeletion.contacts);
      console.log("   - 일정:", geminiResult.dataDeletion.schedule?.length || 0, "개", geminiResult.dataDeletion.schedule);
      console.log("   - 가계부:", geminiResult.dataDeletion.expenses?.length || 0, "개", geminiResult.dataDeletion.expenses);
      console.log("   - 메모:", geminiResult.dataDeletion.diary?.length || 0, "개", geminiResult.dataDeletion.diary);
    }
    console.log("█".repeat(60) + "\n");

    return geminiResult;

  } catch (error) {
    // 6. 로컬 모델 오류 발생 → Gemini로 폴백
    console.error("❌ [로컬 모델 오류]:", error);
    console.log("🔄 [폴백] Gemini API로 전환 (오류 복구)\n");

    const geminiResult = await processWithGemini(chatHistory, text, image, contextData);

    console.log("✅ [Gemini 처리 완료]");
    console.log("🎯 [최종 모델]: Gemini API (오류 폴백)");
    console.log("💬 [답변]:", geminiResult.answer.substring(0, 100) + (geminiResult.answer.length > 100 ? "..." : ""));
    console.log("📋 [파싱 결과]:");
    console.log("   - 연락처:", geminiResult.dataExtraction.contacts.length, "개", geminiResult.dataExtraction.contacts);
    console.log("   - 일정:", geminiResult.dataExtraction.schedule.length, "개", geminiResult.dataExtraction.schedule);
    console.log("   - 가계부:", geminiResult.dataExtraction.expenses.length, "개", geminiResult.dataExtraction.expenses);
    console.log("   - 메모:", geminiResult.dataExtraction.diary.length, "개", geminiResult.dataExtraction.diary);
    if (geminiResult.dataModification) {
      console.log("🔧 [수정 요청]:");
      console.log("   - 연락처:", geminiResult.dataModification.contacts?.length || 0, "개", geminiResult.dataModification.contacts);
      console.log("   - 일정:", geminiResult.dataModification.schedule?.length || 0, "개", geminiResult.dataModification.schedule);
      console.log("   - 가계부:", geminiResult.dataModification.expenses?.length || 0, "개", geminiResult.dataModification.expenses);
      console.log("   - 메모:", geminiResult.dataModification.diary?.length || 0, "개", geminiResult.dataModification.diary);
    }
    if (geminiResult.dataDeletion) {
      console.log("🗑️  [삭제 요청]:");
      console.log("   - 연락처:", geminiResult.dataDeletion.contacts?.length || 0, "개", geminiResult.dataDeletion.contacts);
      console.log("   - 일정:", geminiResult.dataDeletion.schedule?.length || 0, "개", geminiResult.dataDeletion.schedule);
      console.log("   - 가계부:", geminiResult.dataDeletion.expenses?.length || 0, "개", geminiResult.dataDeletion.expenses);
      console.log("   - 메모:", geminiResult.dataDeletion.diary?.length || 0, "개", geminiResult.dataDeletion.diary);
    }
    console.log("█".repeat(60) + "\n");

    return geminiResult;
  }
};

/**
 * 로컬 모델 서버 수동 재연결
 */
export const reconnectLocalModel = async (): Promise<boolean> => {
  console.log("🔄 로컬 모델 서버 재연결 시도...");
  localModelAvailable = null; // 캐시 초기화
  const available = await isLocalModelAvailable();
  if (available) {
    console.log("✅ 로컬 모델 서버 연결 성공!");
  } else {
    console.log("❌ 로컬 모델 서버 연결 실패");
  }
  return available;
};
