import type { ConversationalResponse, Contact, ScheduleItem, Expense, DiaryEntry } from "../types.ts";

const LOCAL_MODEL_API_URL = "http://localhost:8000/api/process";
const HEALTH_CHECK_URL = "http://localhost:8000/api/health";

export interface LocalModelResponse {
  answer: string;
  dataExtraction: {
    contacts: Partial<Contact>[];
    schedule: ScheduleItem[];
    expenses: Expense[];
    diary: DiaryEntry[];
  };
  usedModel: string;
  canHandle: boolean;
  parseResult: string | null;
  processingDetails: string;
  clarificationNeeded?: boolean;
  clarificationOptions?: string[];
}

/**
 * 로컬 모델 서버 상태 확인
 */
export const checkLocalModelHealth = async (): Promise<boolean> => {
  try {
    const response = await fetch(HEALTH_CHECK_URL, {
      method: 'GET',
      signal: AbortSignal.timeout(2000), // 2초 타임아웃
    });
    return response.ok;
  } catch (error) {
    console.warn("⚠️ 로컬 모델 서버에 연결할 수 없습니다:", error);
    return false;
  }
};

/**
 * 로컬 LoRA 모델로 텍스트 처리
 * @param text 사용자 입력 텍스트
 * @param contextData 기존 사용자 데이터 (연락처, 일정, 가계부, 다이어리)
 * @returns 처리 결과
 */
export const processWithLocalModel = async (
  text: string,
  contextData: {
    contacts: Partial<Contact>[];
    schedule: ScheduleItem[];
    expenses: Expense[];
    diary: DiaryEntry[];
  }
): Promise<LocalModelResponse> => {
  console.log("\n" + "=".repeat(60));
  console.log("🤖 [로컬 모델 서비스] 요청 시작");
  console.log("📝 [입력 텍스트]:", text);

  try {
    const response = await fetch(LOCAL_MODEL_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        contextData,
      }),
      signal: AbortSignal.timeout(10000), // 10초 타임아웃
    });

    if (!response.ok) {
      throw new Error(`로컬 모델 서버 오류: ${response.status} ${response.statusText}`);
    }

    const result: LocalModelResponse = await response.json();

    console.log("✅ [처리 완료]");
    console.log("🎯 [사용된 모델]:", result.usedModel);
    console.log("📊 [파싱 결과]:", result.parseResult ? result.parseResult.substring(0, 100) + '...' : 'N/A');
    console.log("💡 [처리 가능 여부]:", result.canHandle ? '✓ 로컬 모델이 처리함' : '✗ Gemini 필요');
    console.log("📋 [추출된 데이터]:");
    console.log("   - 연락처:", result.dataExtraction.contacts.length, "개");
    console.log("   - 일정:", result.dataExtraction.schedule.length, "개");
    console.log("   - 지출/수입:", result.dataExtraction.expenses.length, "개");
    console.log("   - 메모:", result.dataExtraction.diary.length, "개");
    console.log("💬 [답변]:", result.answer);
    console.log("🔍 [처리 내역]:", result.processingDetails);
    console.log("=".repeat(60) + "\n");

    return result;

  } catch (error) {
    console.error("❌ [로컬 모델 오류]:", error);
    console.log("⚠️ [폴백] Gemini로 전환 필요");
    console.log("=".repeat(60) + "\n");

    // 오류 발생시 처리 불가능으로 반환 (Gemini로 폴백하도록)
    return {
      answer: "",
      dataExtraction: {
        contacts: [],
        schedule: [],
        expenses: [],
        diary: [],
      },
      usedModel: "local-error",
      canHandle: false,
      parseResult: null,
      processingDetails: `로컬 모델 서버 오류: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
};

/**
 * 로컬 모델 응답을 ConversationalResponse 형식으로 변환
 */
export const convertToConversationalResponse = (
  localResponse: LocalModelResponse
): ConversationalResponse => {
  return {
    answer: localResponse.answer,
    clarificationNeeded: localResponse.clarificationNeeded || false,
    clarificationOptions: localResponse.clarificationOptions || [],
    dataExtraction: localResponse.dataExtraction,
    dataModification: {
      contacts: [],
      schedule: [],
      expenses: [],
      diary: [],
    },
    dataDeletion: {
      contacts: [],
      schedule: [],
      expenses: [],
      diary: [],
    },
  };
};
