
import React, { useState } from 'react';
import { CategorizedData, Contact, ScheduleItem, Expense, DiaryEntry } from '../types';
import { ContactIcon, ScheduleIcon, ExpenseIcon, DiaryIcon } from './icons';

interface DataSelectionModalProps {
  data: CategorizedData;
  onConfirm: (selectedData: CategorizedData) => void;
  onCancel: () => void;
  title?: string;
}

export const DataSelectionModal: React.FC<DataSelectionModalProps> = ({ data, onConfirm, onCancel, title }) => {
  const [selectedContacts, setSelectedContacts] = useState<Set<string>>(new Set(data.contacts.map(c => c.id)));
  const [selectedSchedule, setSelectedSchedule] = useState<Set<string>>(new Set(data.schedule.map(s => s.id)));
  const [selectedExpenses, setSelectedExpenses] = useState<Set<string>>(new Set(data.expenses.map(e => e.id)));
  const [selectedDiary, setSelectedDiary] = useState<Set<string>>(new Set(data.diary.map(d => d.id)));

  const toggleSelection = (id: string, set: Set<string>, setFn: React.Dispatch<React.SetStateAction<Set<string>>>) => {
    const newSet = new Set(set);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setFn(newSet);
  };

  const handleConfirm = () => {
    const finalData: CategorizedData = {
      contacts: data.contacts.filter(c => selectedContacts.has(c.id)),
      schedule: data.schedule.filter(s => selectedSchedule.has(s.id)),
      expenses: data.expenses.filter(e => selectedExpenses.has(e.id)),
      diary: data.diary.filter(d => selectedDiary.has(d.id)),
    };
    onConfirm(finalData);
  };

  const renderSection = <T extends { id: string }>(
    title: string,
    items: T[],
    selectedSet: Set<string>,
    setFn: React.Dispatch<React.SetStateAction<Set<string>>>,
    Icon: React.FC<React.SVGProps<SVGSVGElement>>,
    renderItem: (item: T) => React.ReactNode
  ) => {
    if (items.length === 0) return null;

    const allSelected = items.every(item => selectedSet.has(item.id));

    const toggleAll = () => {
        if (allSelected) {
            setFn(new Set());
        } else {
            setFn(new Set(items.map(i => i.id)));
        }
    };

    return (
      <div className="mb-6 last:mb-0">
        <div className="flex items-center justify-between mb-2">
            <h4 className="font-bold text-cyan-700 text-sm flex items-center gap-2">
            <Icon className="h-5 w-5" />
            {title} ({items.length})
            </h4>
            <button onClick={toggleAll} className="text-xs text-cyan-600 hover:underline">
                {allSelected ? '선택 해제' : '전체 선택'}
            </button>
        </div>
        <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
          {items.map(item => (
            <div 
                key={item.id} 
                className="flex items-start gap-3 p-3 border-b border-gray-100 last:border-0 hover:bg-gray-50 cursor-pointer"
                onClick={() => toggleSelection(item.id, selectedSet, setFn)}
            >
              <input
                type="checkbox"
                checked={selectedSet.has(item.id)}
                onChange={() => {}} // Handled by div click
                className="mt-1 h-4 w-4 text-cyan-600 rounded border-gray-300 focus:ring-cyan-500 cursor-pointer"
              />
              <div className="flex-grow text-sm text-gray-700">
                {renderItem(item)}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-900">{title || "데이터 선택"}</h2>
          <button onClick={onCancel} className="text-gray-500 hover:text-gray-800">✕</button>
        </div>
        
        <div className="p-6 overflow-y-auto bg-gray-50">
            <p className="text-sm text-gray-600 mb-4">
                다음 정보가 추출되었습니다. 저장할 항목을 선택해주세요.
            </p>

            {data.contacts.length === 0 && data.schedule.length === 0 && data.expenses.length === 0 && data.diary.length === 0 && (
                <div className="text-center py-10 text-gray-500">
                    추출된 데이터가 없습니다.
                </div>
            )}

            {renderSection('연락처', data.contacts, selectedContacts, setSelectedContacts, ContactIcon, (c: Contact) => (
                <>
                    <p className="font-bold">{c.name}</p>
                    <p className="text-xs text-gray-500">{c.phone || c.email || '연락처 정보 없음'}</p>
                </>
            ))}

            {renderSection('일정', data.schedule, selectedSchedule, setSelectedSchedule, ScheduleIcon, (s: ScheduleItem) => (
                <>
                    <p className="font-bold">{s.title}</p>
                    <p className="text-xs text-gray-500">{s.date} {s.time} {s.location ? `@ ${s.location}` : ''}</p>
                </>
            ))}

            {renderSection('가계부', data.expenses, selectedExpenses, setSelectedExpenses, ExpenseIcon, (e: Expense) => (
                <div className="flex justify-between">
                    <div>
                        <p className="font-bold">{e.item}</p>
                        <p className="text-xs text-gray-500">{e.date} | {e.category || '미분류'}</p>
                    </div>
                    <p className={`font-bold ${e.type === 'income' ? 'text-green-600' : 'text-blue-600'}`}>
                        {e.amount.toLocaleString()}원
                    </p>
                </div>
            ))}

            {renderSection('메모', data.diary, selectedDiary, setSelectedDiary, DiaryIcon, (d: DiaryEntry) => (
                <>
                    <p className="font-bold mb-1">{d.date}</p>
                    <p className="text-xs text-gray-600 whitespace-pre-wrap">{d.entry}</p>
                </>
            ))}
        </div>

        <div className="flex justify-end items-center p-4 border-t border-gray-200 gap-3 bg-white rounded-b-lg">
          <button
            onClick={onCancel}
            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
          >
            취소
          </button>
          <button
            onClick={handleConfirm}
            className="px-4 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors shadow-sm"
          >
            선택 항목 저장
          </button>
        </div>
      </div>
    </div>
  );
};
