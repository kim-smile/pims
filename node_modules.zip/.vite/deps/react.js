import {
  require_react
} from "./chunk-TOPHTIRU.js";
import "./chunk-BUSYA2B4.js";
export default require_react();
