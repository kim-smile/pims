import {
  require_react_dom
} from "./chunk-RREYUWCL.js";
import "./chunk-TOPHTIRU.js";
import "./chunk-BUSYA2B4.js";
export default require_react_dom();
